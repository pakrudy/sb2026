<div>
     <?php $__env->slot('title', null, []); ?> Daftar Data Barang & Fee Cabang <?php $__env->endSlot(); ?>

    <?php
        $user = Auth::user();
        $userCabang = $user ? $user->cabang : null;
        $isHkUser = $userCabang && $userCabang->tipe_lokasi === 'hongkong';
        $isPusatUser = $userCabang && $userCabang->kategori_cabang === 'PUSAT';
    ?>

    <!-- Header -->
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Manajemen & Rekap Data Barang</h1>
            <p class="text-xs text-slate-500 mt-1">Daftar seluruh barang terdaftar, filter berdasarkan status, cabang, atau kategori fee ESB/ELP.</p>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isHkUser && !$isPusatUser): ?>
        <a href="<?php echo e(route('input-barang')); ?>" class="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow transition">
            ➕ Input Barang Baru
        </a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <!-- Filters & Search Bar -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm mb-6 space-y-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <!-- Search -->
            <div>
                <label class="block text-xs font-bold text-slate-700 mb-1">Cari Resi / Nama / WA</label>
                <input type="text" wire:model.live.debounce.300ms="search" placeholder="Contoh: ESB-2026... atau Dewi"
                    class="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <!-- Filter Status -->
            <div>
                <label class="block text-xs font-bold text-slate-700 mb-1">Status Barang</label>
                <select wire:model.live="filterStatus" class="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                    <option value="">Semua Status</option>
                    <option value="diterima_di_cabang">Diterima di Cabang</option>
                    <option value="dalam_perjalanan_ke_pusat">Dalam Perjalanan ke Pusat</option>
                    <option value="disortir_di_pusat">Disortir di Pusat (Boxed)</option>
                    <option value="dalam_pengiriman_hk">Dalam Pengiriman ke HK</option>
                    <option value="sampai_di_hk">Sampai di Cabang HK</option>
                    <option value="sudah_diambil">Sudah Diambil</option>
                </select>
            </div>

            <!-- Filter Cabang -->
            <div>
                <label class="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                    <span>Cabang Asal</span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isCabangLocked): ?>
                    <span class="text-[10px] text-slate-600 font-normal">🔒 Cabang Anda</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </label>
                <select wire:model.live="filterCabangAsal"
                    <?php if($isCabangLocked): ?> disabled <?php endif; ?>
                    class="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none <?php if($isCabangLocked): ?> bg-slate-100/90 text-slate-700 cursor-not-allowed opacity-85 <?php endif; ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isCabangLocked): ?>
                    <option value="">Semua Cabang Asal</option>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $cabangIndo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($cb->id); ?>"><?php echo e($cb->nama_cabang); ?> (<?php echo e($cb->kategori_cabang); ?>)</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </select>
            </div>

            <!-- Filter Kategori Fee -->
            <div>
                <label class="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                    <span>Kategori Fee Cabang</span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isKategoriLocked): ?>
                    <span class="text-[10px] text-slate-600 font-normal">🔒 Dikunci (<?php echo e($filterKategori); ?>)</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </label>
                <select wire:model.live="filterKategori"
                    <?php if($isKategoriLocked): ?> disabled <?php endif; ?>
                    class="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none <?php if($isKategoriLocked): ?> bg-slate-100/90 text-slate-700 cursor-not-allowed opacity-85 <?php endif; ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isKategoriLocked): ?>
                    <option value="">Semua Kategori (ESB & ELP)</option>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <option value="ESB">Kategori ESB (Rp 1.000/kg)</option>
                    <option value="ELP">Kategori ELP (Rp 2.000/kg)</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Datatable -->
    <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-slate-50 text-slate-600 uppercase tracking-wider border-b border-slate-200 font-bold">
                    <tr>
                        <th class="p-4">Kode Resi</th>
                        <th class="p-4">Tanggal Kirim</th>
                        <th class="p-4">Cabang Asal (Kat)</th>
                        <th class="p-4">Cabang HK</th>
                        <th class="p-4">Pengirim & Penerima</th>
                        <th class="p-4 text-right">Berat (kg)</th>
                        <th class="p-4 text-right">Fee Cabang</th>
                        <th class="p-4">Status</th>
                        <th class="p-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $barangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="p-4 font-mono font-bold text-slate-900">
                            <div><?php echo e($b->kode_barang); ?></div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($b->box): ?>
                            <span class="inline-block mt-0.5 text-[10px] text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded font-mono border border-purple-200">
                                <?php echo e($b->box->kode_box); ?>

                            </span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>
                        <td class="p-4 text-slate-600 font-mono">
                            <?php echo e($b->tanggal_pengiriman ? $b->tanggal_pengiriman->format('d/m/Y H:i') : '-'); ?>

                        </td>
                        <td class="p-4">
                            <div class="font-bold text-slate-800"><?php echo e($b->cabangAsal->nama_cabang); ?></div>
                        </td>
                        <td class="p-4 font-bold text-indigo-700">
                            <?php echo e($b->cabangTujuan->nama_cabang); ?>

                        </td>
                        <td class="p-4">
                            <div class="font-bold text-slate-900">Penerima: <?php echo e($b->nama_penerima); ?></div>
                            <div class="text-[11px] text-slate-500 font-mono">WA: <?php echo e($b->no_wa_penerima); ?></div>
                            <div class="text-[10px] text-slate-400 mt-0.5">Pengirim: <?php echo e($b->nama_pengirim); ?></div>
                        </td>
                        <td class="p-4 text-right font-bold text-slate-900">
                            <?php echo e(number_format($b->berat_kg, 2, ',', '.')); ?> kg
                        </td>
                        <td class="p-4 text-right font-bold text-emerald-700">
                            Rp <?php echo e(number_format($b->fee_cabang, 0, ',', '.')); ?>

                        </td>
                        <td class="p-4">
                            <?php
                                $statusBadges = [
                                    'diterima_di_cabang' => ['bg-yellow-100 text-yellow-800', 'Diterima Cabang'],
                                    'dalam_perjalanan_ke_pusat' => ['bg-blue-100 text-blue-800', 'Ke Hub Pusat'],
                                    'disortir_di_pusat' => ['bg-purple-100 text-purple-800', 'Disortir (Boxed)'],
                                    'dalam_pengiriman_hk' => ['bg-indigo-100 text-indigo-800', 'Pengiriman HK'],
                                    'sampai_di_hk' => ['bg-teal-100 text-teal-800', 'Tiba HK'],
                                    'sudah_diambil' => ['bg-emerald-100 text-emerald-800', 'Sudah Diambil'],
                                ];
                                $st = $statusBadges[$b->status] ?? ['bg-slate-100 text-slate-800', $b->status];
                            ?>
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-bold <?php echo e($st[0]); ?>">
                                <?php echo e($st[1]); ?>

                            </span>
                        </td>
                        <td class="p-4 text-center">
                            <a href="<?php echo e(route('print.resi', $b->id)); ?>" target="_blank"
                                class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-[11px] font-bold transition inline-flex items-center space-x-1">
                                <span>🖨️ Cetak</span>
                            </a>
                        </td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <tr>
                        <td colspan="9" class="p-8 text-center text-slate-400">Tidak ada data barang yang sesuai dengan filter.</td>
                    </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="p-4 border-t border-slate-100">
            <?php echo e($barangList->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH D:\xampp8.2\htdocs\sb2026\resources\views/livewire/daftar-barang.blade.php ENDPATH**/ ?>