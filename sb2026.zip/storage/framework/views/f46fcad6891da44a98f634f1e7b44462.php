<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

     <?php $__env->slot('title', null, []); ?> Dashboard Overview <?php $__env->endSlot(); ?>

    <?php
        $user = Auth::user();
        $isCabangUser = $user && $user->cabang_id && !$user->isSuperAdmin();
        $userCabang = $user ? $user->cabang : null;
        $isHkBranchUser = $isCabangUser && $userCabang && $userCabang->tipe_lokasi === 'hongkong';
        $isPusatUser = $isCabangUser && $userCabang && $userCabang->kategori_cabang === 'PUSAT';

        $barangQuery = \App\Models\Barang::query();
        if ($isCabangUser) {
            if ($isHkBranchUser) {
                $barangQuery->where('cabang_tujuan_id', $user->cabang_id);
            } else {
                $barangQuery->where('cabang_asal_id', $user->cabang_id);
            }
        }

        $totalBarang = (clone $barangQuery)->count();
        $totalKg = (clone $barangQuery)->sum('berat_kg');

        if ($isCabangUser) {
            $userFeeTotal = (clone $barangQuery)->sum('fee_cabang');
        } else {
            $totalFeeEsb = \App\Models\Barang::where('kategori_cabang_snapshot', 'ESB')->sum('fee_cabang');
            $totalFeeElp = \App\Models\Barang::where('kategori_cabang_snapshot', 'ELP')->sum('fee_cabang');
        }

        $barangProgres = (clone $barangQuery)->whereNotIn('status', ['sudah_diambil'])->count();
        $barangDone = (clone $barangQuery)->where('status', 'sudah_diambil')->count();

        $recentBarang = (clone $barangQuery)->with(['cabangAsal', 'cabangTujuan'])->latest()->take(6)->get();
    ?>

    <!-- Welcome Hero Banner -->
    <div class="mb-8 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white shadow-xl relative overflow-hidden">
        <div class="absolute -right-10 -bottom-10 opacity-10 pointer-events-none">
            <svg class="w-72 h-72 text-emerald-400" fill="currentColor" viewBox="0 0 24 24">
                <path d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
        </div>

        <div class="relative z-10">
            <span class="inline-block px-3 py-1 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 rounded-full text-xs font-semibold mb-3">
                📍 Logistik Express Indonesia ➔ Hong Kong
            </span>
            <h1 class="text-2xl sm:text-3xl font-extrabold tracking-tight">Selamat Datang, <?php echo e($user->name); ?>!</h1>
            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isCabangUser && $userCabang): ?>
            <p class="mt-2 text-slate-300 text-sm max-w-2xl">
                Dashboard Operasional <strong><?php echo e($userCabang->nama_cabang); ?></strong> 
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isHkBranchUser): ?>
                . Kategori Cabang: <strong class="text-emerald-400"><?php echo e($userCabang->kategori_cabang); ?> (Fee Rp <?php echo e(number_format($userCabang->fee_per_kg, 0, ',', '.')); ?>/kg)</strong>.
                <?php else: ?>
                (Lokasi Tujuan Hong Kong).
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </p>
            <?php else: ?>
            <p class="mt-2 text-slate-300 text-sm max-w-2xl">
                Aplikasi Pengelolaan Pengiriman Barang "Ekspedisi Sukses Bersama".
            </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="mt-6 flex flex-wrap gap-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isHkBranchUser && !$isPusatUser): ?>
                <a href="<?php echo e(route('input-barang')); ?>" class="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition">
                    ➕ Input Penerimaan Barang Baru
                </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <a href="<?php echo e(route('daftar-barang')); ?>" class="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition">
                    📦 Lihat Data Barang <?php echo e($isCabangUser ? 'Cabang Saya' : ''); ?>

                </a>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isCabangUser || $isPusatUser || $user->isAdminPusat()): ?>
                <a href="<?php echo e(route('sorting-pusat')); ?>" class="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition">
                    🏢 Sortir & Packing Box Pusat
                </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isCabangUser || $isHkBranchUser || $user->isAdminCabangHk()): ?>
                <a href="<?php echo e(route('cabang-hk')); ?>" class="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg transition">
                    🇭🇰 Pengambilan Barang HK
                </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Stat Cards Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 <?php echo e($isCabangUser ? ($isHkBranchUser ? 'lg:grid-cols-2' : 'lg:grid-cols-3') : 'lg:grid-cols-4'); ?> gap-5 mb-8">
        <!-- Card 1: Total Barang -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Total Barang <?php echo e($isCabangUser ? 'Cabang' : ''); ?>

                </span>
                <div class="text-3xl font-extrabold text-slate-900 mt-1"><?php echo e(number_format($totalBarang)); ?></div>
                <span class="text-[11px] text-slate-500 mt-1 block">Total kg: <strong class="text-emerald-600"><?php echo e(number_format($totalKg, 2, ',', '.')); ?> kg</strong></span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl font-bold">
                📦
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isCabangUser && $userCabang && !$isHkBranchUser): ?>
        <!-- Single Card for Indonesia Origin Branch Admin: Fee Cabang Saya -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <span class="text-xs font-bold text-emerald-600 uppercase tracking-wider">
                    Total Fee Cabang <?php echo e($userCabang->kategori_cabang); ?>

                </span>
                <div class="text-2xl font-extrabold text-slate-900 mt-1">Rp <?php echo e(number_format($userFeeTotal, 0, ',', '.')); ?></div>
                <span class="text-[11px] text-slate-500 mt-1 block">Tarif: Rp <?php echo e(number_format($userCabang->fee_per_kg, 0, ',', '.')); ?> / kg</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center text-xs font-black">
                <?php echo e($userCabang->kategori_cabang); ?>

            </div>
        </div>
        <?php elseif(!$isCabangUser): ?>
        <!-- Card 2: Fee Cabang ESB (Super Admin) -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <span class="text-xs font-bold text-emerald-600 uppercase tracking-wider">Fee Cabang ESB</span>
                <div class="text-2xl font-extrabold text-slate-900 mt-1">Rp <?php echo e(number_format($totalFeeEsb, 0, ',', '.')); ?></div>
                <span class="text-[11px] text-slate-500 mt-1 block">Fee Rp 1.000 / kg</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center text-xs font-black">
                ESB
            </div>
        </div>

        <!-- Card 3: Fee Cabang ELP (Super Admin) -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <span class="text-xs font-bold text-teal-600 uppercase tracking-wider">Fee Cabang ELP</span>
                <div class="text-2xl font-extrabold text-slate-900 mt-1">Rp <?php echo e(number_format($totalFeeElp, 0, ',', '.')); ?></div>
                <span class="text-[11px] text-slate-500 mt-1 block">Fee Rp 2.000 / kg</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 border border-teal-200 flex items-center justify-center text-xs font-black">
                ELP
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <!-- Card 4: Aktif Dalam Perjalanan / Proses -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <span class="text-xs font-bold text-indigo-600 uppercase tracking-wider">Aktif Dalam Proses</span>
                <div class="text-3xl font-extrabold text-slate-900 mt-1"><?php echo e(number_format($barangProgres)); ?></div>
                <span class="text-[11px] text-emerald-600 font-semibold mt-1 block">Selesai: <?php echo e(number_format($barangDone)); ?> barang</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl font-bold">
                ✈️
            </div>
        </div>
    </div>

    <!-- Recent Shipments Table -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="p-6 border-b border-slate-100 flex items-center justify-between">
            <div>
                <h2 class="text-base font-bold text-slate-900">
                    Pengiriman Terbaru <?php echo e($isCabangUser && $userCabang ? "({$userCabang->nama_cabang})" : '(Seluruh Cabang)'); ?>

                </h2>
                <p class="text-xs text-slate-500">
                    6 data pengiriman barang terakhir <?php echo e($isCabangUser ? ($isHkBranchUser ? 'yang ditujukan ke cabang HK Anda.' : 'yang diterima di cabang Anda.') : 'yang diinput ke aplikasi.'); ?>

                </p>
            </div>
            <a href="<?php echo e(route('daftar-barang')); ?>" class="text-xs font-bold text-emerald-600 hover:text-emerald-700">
                Lihat Semua Data ➔
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-slate-50 text-slate-600 uppercase tracking-wider border-b border-slate-100 font-bold">
                    <tr>
                        <th class="p-4">Kode Resi</th>
                        <th class="p-4">Cabang Asal (Kategori)</th>
                        <th class="p-4">Tujuan HK</th>
                        <th class="p-4">Penerima</th>
                        <th class="p-4 text-right">Berat (kg)</th>
                        <th class="p-4 text-right">Fee Cabang</th>
                        <th class="p-4">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="p-4 font-mono font-bold text-slate-900"><?php echo e($b->kode_barang); ?></td>
                        <td class="p-4">
                            <span class="font-medium text-slate-800"><?php echo e($b->cabangAsal->nama_cabang); ?></span>
                            <span class="ml-1 inline-block px-2 py-0.5 rounded text-[10px] font-bold <?php echo e($b->kategori_cabang_snapshot === 'ESB' ? 'bg-emerald-100 text-emerald-800' : 'bg-teal-100 text-teal-800'); ?>">
                                <?php echo e($b->kategori_cabang_snapshot); ?>

                            </span>
                        </td>
                        <td class="p-4 font-medium text-indigo-700"><?php echo e($b->cabangTujuan->nama_cabang); ?></td>
                        <td class="p-4">
                            <div class="font-bold text-slate-900"><?php echo e($b->nama_penerima); ?></div>
                            <div class="text-[11px] text-slate-500 font-mono"><?php echo e($b->no_wa_penerima); ?></div>
                        </td>
                        <td class="p-4 text-right font-bold text-slate-800"><?php echo e(number_format($b->berat_kg, 2, ',', '.')); ?> kg</td>
                        <td class="p-4 text-right font-bold text-emerald-600">Rp <?php echo e(number_format($b->fee_cabang, 0, ',', '.')); ?></td>
                        <td class="p-4">
                            <?php
                                $statusBadges = [
                                    'diterima_di_cabang' => ['bg-yellow-100 text-yellow-800', 'Diterima Cabang'],
                                    'dalam_perjalanan_ke_pusat' => ['bg-blue-100 text-blue-800', 'Ke Hub Pusat'],
                                    'disortir_di_pusat' => ['bg-purple-100 text-purple-800', 'Sortir Pusat'],
                                    'dalam_pengiriman_hk' => ['bg-indigo-100 text-indigo-800', 'Pengiriman HK'],
                                    'sampai_di_hk' => ['bg-teal-100 text-teal-800', 'Tiba HK'],
                                    'sudah_diambil' => ['bg-emerald-100 text-emerald-800', 'Sudah Diambil'],
                                ];
                                $st = $statusBadges[$b->status] ?? ['bg-slate-100 text-slate-800', $b->status];
                            ?>
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-bold <?php echo e($st[0]); ?>">
                                <?php echo e($st[1]); ?>

                            </span>
                        </td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <tr>
                        <td colspan="7" class="p-8 text-center text-slate-400 text-xs">Belum ada data barang di cabang ini.</td>
                    </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8.2\htdocs\sb2026\resources\views/dashboard.blade.php ENDPATH**/ ?>